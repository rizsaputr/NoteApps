package com.rizqi.note.utils

import com.rizqi.note.model.ModelNote

interface onClickItemListener {
    fun onClick(modelNote: ModelNote, position: Int)
}